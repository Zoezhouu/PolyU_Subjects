import oracle.jdbc.driver.OracleConnection;
import oracle.jdbc.driver.OracleDriver;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.sql.*;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Scanner;

public class Controller {
    public static String msg;
    static String accountId;
    static Scanner scanner = new Scanner(System.in);
    static OracleConnection conn;

    public static void main(String[] args) throws SQLException {
        String username = "\"20084413d\"";         // e.g. "98765432d"
        String pwd = "yedwebcs";
        // Connection
        DriverManager.registerDriver(new OracleDriver());
        conn = (OracleConnection) DriverManager.getConnection(
                "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms", username, pwd);

        Statement stmt = conn.createStatement();
        stmt.executeQuery("update patron_account set IS_deactivated = 'YES' where account_id IN (select account_id from borrow_order where due_time < sysdate and Is_returned = 'NO')");
        //Main logic
        String uOrm = originFace();
        if (uOrm.equals("man")) {
            while (true) {
                switch (managerFace()) {
                    case "1":
                        while (searchFace() == 0) {
                        }
                        break;
                    case "2":
                        recordFace();
                        if (!wantback()
                        ) {
                            return;
                        }
                        break;
                    case "3":
                        noticeFace();
                        if (!wantback()
                        ) {
                            return;
                        }
                        break;
                    case "4":
                        returnFace();
                        if (!wantback()
                        ) {
                            return;
                        }
                        break;
                    case "5":
                        cancelFace();
                        if (!wantback()
                        ) {
                            return;
                        }
                        break;
                    case "6":
                        reportFace();
                        if (!wantback()
                        ) {
                            return;
                        }
                        break;
                    case "7":
                        deactivateFace();
                        if (!wantback()
                        ) {
                            return;
                        }
                        break;
                    case "8":
                        activateFace();
                        if (!wantback()
                        ) {
                            return;
                        }
                        break;
                    case "quit":
                        return;
                }
            }
        } else if (uOrm.equals("use")) {
            while (true) {
                switch (userFace()) {
                    case "1":
                        while (searchFace() == 0) {
                        }
                        break;
                    case "2":
                        recordFace();
                        if (!wantback()
                        ) {
                            return;
                        }
                        break;
                    case "3":
                        noticeFace();
                        if (!wantback()
                        ) {
                            return;
                        }
                        break;
                    case "4":
                        returnFace();
                        if (!wantback()
                        ) {
                            return;
                        }
                        break;
                    case "5":
                        cancelFace();
                        break;
                    case "quit":
                        return;
                }
            }
        }
    }

    public static boolean wantback() {
        System.out.println("Do you want to back to the main page or quit? (enter back/quit)");
        updateMsg();
        String input = msg;
        while (!input.equals("back") && !input.equals("quit")) {
            System.out.println("The enter is not legal, please enter back or quit!");
            updateMsg();
            input = msg;
        }
        return input.equals("back") ? true : false;
    }

    public static String originFace() throws SQLException {
        String passWord;

        Statement stmt = conn.createStatement();

        System.out.println("|--------------------------------------------------------------|");
        System.out.println("|                 Library Management System                    |");
        System.out.println("|                          Log in                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  | Please enter your ID |:");
        updateMsg();
        accountId = msg;
        String type;
        ResultSet rset = stmt.executeQuery("select ACCOUNT_PASSWORD, IS_DEACTIVATED from patron_account where account_id = '" + msg + "'");
        if (rset.next()) {
            passWord = rset.getString("ACCOUNT_PASSWORD");
            String status = rset.getString("IS_DEACTIVATED");
            if (status.equals("YES")) {
                System.out.println("\033[31mYour account is DEACTIVATED! Please contact the library staff.\033[0m");
                return "block";
            }
            type = "use";
        } else {
            rset = stmt.executeQuery("select M_password from manager where M_ID = '" + msg + "'");
            if (rset.next()) {
                passWord = rset.getString("M_password");
                type = "man";
            } else {
                while (true) {
                    System.out.println("The ID is not exist, please enter again!");
                    updateMsg();
                    accountId = msg;
                    rset = stmt.executeQuery("select ACCOUNT_PASSWORD, IS_DEACTIVATED from patron_account where account_id = '" + msg + "'");
                    if (rset.next()) {
                        passWord = rset.getString("ACCOUNT_PASSWORD");
                        String status = rset.getString("IS_DEACTIVATED");
                        type = status.equals("YES") ? "quit" : "use";
                        break;
                    } else {
                        rset = stmt.executeQuery("select M_password from manager where M_ID = '" + msg + "'");
                        if (rset.next()) {
                            passWord = rset.getString("M_password");
                            type = "man";
                            break;
                        }
                    }
                }
            }
        }
        System.out.println("|   ----------------------                                     |");
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  | Please enter your password |:");
        updateMsg();
        String password = msg;
        while (!password.equals(passWord)) {
            System.out.println("The password is not right, please enter again!");
            updateMsg();
            password = msg;
        }
        System.out.println("|   ----------------------                                     |");
        System.out.println("|                                                              |");
        System.out.println("|                          Welcome!                            |");
        System.out.println("|--------------------------------------------------------------|");
        rset = stmt.executeQuery("select a.book_name from book a where(a.book_id IN (select b.book_id from stat b where( b.book_id IN (select c.book_id from desire c where c.account_id = '" + accountId + "') and b.Is_borrowed = 'NO' and b.IS_RESERVED = 'NO')))");
        if (rset.next()) {
            String bookName = rset.getString("BOOK_NAME");
            rset = stmt.executeQuery(String.format("select EMAIL from PATRON_ACCOUNT where ACCOUNT_ID='%s'",
                    accountId));
            if (rset.next()) {
                String receiver = rset.getString("EMAIL");
                sendEmail(receiver, bookName);
            }
        }
        return type;
    }


    public static String userFace() throws SQLException {
        Statement stmt = conn.createStatement();
        ResultSet rset;
        System.out.println("|--------------------------------------------------------------|");
        System.out.println("|                           Main Page                          |");
        System.out.println("|                                                              |");
        System.out.println("|                  What do you want to do?                     |");
        System.out.println("|                Enter '1' for searching books                 |");
        System.out.println("|                Enter '2' for checking records                |");
        System.out.println("|                Enter '3' for reading notice                  |");
        System.out.println("|                Enter '4' for returning books                 |");
        System.out.println("|                Enter '5' for cancelling reserve              |");
        System.out.println("|                Enter 'quit' for quiting                      |");
        System.out.println("|                                                              |");
        System.out.println("|   --------------       --------------      -------------     |");
        System.out.println("|   | Search for |       | Check your |      | Important |     |");
        System.out.println("|   |    Books   |       |   Records  |      |  Notice   |     |");
        System.out.println("|   --------------       --------------      -------------     |");
        System.out.println("|                                                              |");
        System.out.println("|   --------------       --------------                        |");
        System.out.println("|   |   Return   |       |  Cancel    |        --------        |");
        System.out.println("|   |   Books    |       |  Reserve   |        | Quit |        |");
        System.out.println("|   --------------       --------------        --------        |");
        System.out.println("|--------------------------------------------------------------|");
        updateMsg();
        String choice = msg;
        while (!choice.equals("1") && !choice.equals("2") && !choice.equals("3") && !choice.equals("quit") && !choice.equals("4") && !choice.equals("5")) {
            System.out.println("The enter is illegal, please enter '1', '2', '3', '4' or '5'!");
            updateMsg();
            choice = msg;
        }
        return choice;
    }

    public static String managerFace() {
        System.out.println("|--------------------------------------------------------------|");
        System.out.println("|                           Main page                          |");
        System.out.println("|                                                              |");
        System.out.println("|                  What do you want to do?                     |");
        System.out.println("|              Enter '1' for searching books                   |");
        System.out.println("|              Enter '2' for checking records                  |");
        System.out.println("|              Enter '3' for reading notice                    |");
        System.out.println("|              Enter '4' for returning books                   |");
        System.out.println("|              Enter '5' for cancelling reserve                |");
        System.out.println("|              Enter '6' for report                            |");
        System.out.println("|              Enter '7' for deactivating patrons              |");
        System.out.println("|              Enter '8' for activating patrons                |");
        System.out.println("|              Enter 'quit' for quiting                        |");
        System.out.println("|                                                              |");
        System.out.println("|    --------------       --------------      -------------    |");
        System.out.println("|    | Search for |       | Check your |      | Important |    |");
        System.out.println("|    |    Books   |       |   Record   |      |  Notice   |    |");
        System.out.println("|    --------------       --------------      -------------    |");
        System.out.println("|                                                              |");
        System.out.println("|    --------------       --------------                       |");
        System.out.println("|    |   Return   |       |   Cancel   |       -----------     |");
        System.out.println("|    |   Books    |       |   Reserve  |       |  Report |     |");
        System.out.println("|    --------------       --------------       -----------     |");
        System.out.println("|                                                              |");
        System.out.println("|    --------------       --------------                       |");
        System.out.println("|    | Deactivate |       |  Activate  |       ----------      |");
        System.out.println("|    |  Patrons   |       |  Patrons   |       |  Quit  |      |");
        System.out.println("|    --------------       --------------       ----------      |");
        System.out.println("|--------------------------------------------------------------|");
        updateMsg();
        String choice = msg;
        while (!choice.equals("1") && !choice.equals("2") && !choice.equals("3") && !choice.equals("4") && !choice.equals("5") && !choice.equals("6") && !choice.equals("7") && !choice.equals("8") && !choice.equals("quit")) {
            System.out.println("The enter is illegal, please enter '1', '2', '3' or '4'!");
            updateMsg();
            choice = msg;
        }
        return choice;
    }

    //0 -> doagiain, -1 -> back to mainpage
    public static int searchFace() throws SQLException {

        Statement stmt = conn.createStatement();
        System.out.println("|--------------------------------------------------------------|");
        System.out.println("|                 Library Management System                    |");
        System.out.println("|                          Searching                           |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|     Please input information of the book you desire below    |");
        System.out.println("|     If you don't know few information, please enter '/'      |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  | Name of the book |:");
        updateMsg();
        String bookName = msg;
        System.out.println("|   ----------------------                                     |");
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  | Author of the book |:");
        updateMsg();
        String author = msg;
        System.out.println("|   ----------------------                                     |");
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  | Category |:");
        updateMsg();
        String category = msg;
        System.out.println("|   ----------------------                                     |");
        System.out.println("|------------------------------------------------------------- |");
        System.out.println("|------------------------------------------------------------- |");
        ResultSet rset = stmt.executeQuery("select distinct a.* from book a where (upper(a.book_name) like upper('%" + bookName + "%') or upper(a.author) like upper('%" + author + "%') or upper(a.category) like upper('%" + category + "%'))");
        if (!rset.next()) {
            do {
                System.out.println("According to given information, there is no book available.");
                System.out.println("If you want to search again, please enter '0'. If you want to go back to main page, please enter \"'back'\"");
                updateMsg();
            } while (!msg.equals("0") && !msg.equals("back"));
            return msg.equals("0") ? 0 : -1;
        }
            /*
            BOOK_ID VARCHAR(20) NOT NULL,
            BOOK_NAME VARCHAR(50) NOT NULL,
            AUTHOR VARCHAR(20) NOT NULL,
            ISBN VARCHAR(13) NOT NULL,
            CATEGORY VARCHAR(20),
            LOCAT VARCHAR(20),
             */
        ArrayList<String> arrayList = new ArrayList<>();
        int i = 1;
        int size = 0;
        rset = stmt.executeQuery("select distinct a.* from book a, stat b where upper(a.book_name) like upper('%" + bookName + "%') or upper(a.author) like upper('%" + author + "%') or upper(a.category) like upper('%" + category + "%')");
        while (rset.next()) {
            String id = rset.getString("BOOK_ID");
            String name = rset.getString("BOOK_NAME");
            String author1 = rset.getString("AUTHOR");
            String isBN = rset.getString("ISBN");
            String category1 = rset.getString("CATEGORY");
            String loc = rset.getString("LOCAT");
            System.out.printf(
                    "\033[32mNumber: %s\nBOOK_ID: %s\nBOOK_NAME: %s\nAUTHOR: %s\nISBN: %s\nCATEGORY: %s\nLOCATION: " +
                    "%s\n\u001B[0m%n", i, id, name, author1, isBN, category1,loc);
            i++;
            arrayList.add(id);
        }
        System.out.println("If you find the book, please enter the number of the book to borrow it. If you want to search again, please enter '0', or you want to go back to main page, please enter \"'back'\"");
        updateMsg();
        if (msg.equals("0")) {
            return 0;
        }
        if (msg.equals("back")) {
            return -1;
        }
        boolean flag = true;
        if (msg.equals("")){
            flag = false;}
        else {
            for (int j = 0; j < msg.length(); j++) {
                if (!(msg.charAt(j) <= '9' && msg.charAt(j) >= '0')) {
                    flag = false;
                    break;
                }
                if ((Integer.parseInt(msg) > arrayList.size()) || (Integer.parseInt(msg) < 1)) flag = false;
            }
        }

        while (true) {
            if (flag == false) {
                System.out.println("You have to enter a book number, '0' to search again, or 'back' to go back to main!");
                updateMsg();
                if (msg.equals("0")) return 0;
                if (msg.equals("back")) return -1;
                flag = true;
                if (msg.equals("")){
                    flag = false;}
                else {
                    for (int j = 0; j < msg.length(); j++) {
                        if (!(msg.charAt(j) <= '9' && msg.charAt(j) >= '0')) {
                            flag = false;
                            break;
                        }
                        if ((Integer.parseInt(msg) > arrayList.size()) || (Integer.parseInt(msg) < 1)) flag = false;
                    }
                }
            } else break;
        }
        int index = Integer.parseInt(msg) - 1;
        String id = arrayList.get(index);
        rset = stmt.executeQuery("select is_borrowed, is_reserved from stat where book_id = '" + id + "'");
        String isB;
        String isR;
        rset.next();
        isB = rset.getString("is_borrowed");
        isR = rset.getString("is_reserved");
        boolean isA = "NO".equals(isB) && "NO".equals(isR) ? true : false;
        if (isA) {
            System.out.println("The book is Available now! You can enter '1' (borrow)(take it now!), '2' (reserve)(take it in 3 days!), '0' (search again) or 'back' (back to main menu)");
            updateMsg();
            if (msg.equals("0")) {
                return 0;
            }
            if (msg.equals("back")) {
                return -1;
            }
            if (msg.equals("1")) {
                stmt.executeQuery("update stat set IS_borrowed = 'YES' where book_id = '" + id + "'");
                stmt.executeQuery("insert into borrow_order(book_id,account_id,is_returned,due_time,note_time) values('" + id + "','" + accountId + "','NO',sysdate+28,sysdate+25)");
                stmt.executeQuery("update book_record set BORROW_times = BORROW_times + 1 where book_id = '" + id + "'");
                System.out.println("Congratulations, your borrow is successful!");
                return -1;
            }
            if (msg.equals("2")) {
                stmt.executeQuery("update stat set Is_reserved = 'YES' where book_id = '" + id + "'");
                stmt.executeQuery("insert into reserve_order(book_id,account_id,cancel_time,is_borrowed,is_canceled) values('" + id + "','" + accountId + "',sysdate+3,'NO')");
                stmt.executeQuery("update book_record set reserve_times = reserve_times + 1 where book_id = '" + id + "'");
                System.out.println("Congratulations, your reserve is successful!");
                return -1;
            }
            while (true) {
                System.out.println("You should enter '1' (borrow)(take it now!), '2' (reserve)(take it in 3 days!), '0' (search again) or 'back' (back to main menu)");
                updateMsg();
                if (msg.equals("0")) return 0;
                if (msg.equals("back")) return -1;
                if (msg.equals("1")) {
                    stmt.executeQuery("update stat set IS_borrowed = 'YES' where book_id = '" + id + "'");
                    stmt.executeQuery("insert into borrow_order(book_id,account_id,is_returned,due_time,note_time) values('" + id + "','" + accountId + "','NO',sysdate+28,sysdate+25)");
                    stmt.executeQuery("update book_record set BORROW_times = BORROW_times + 1 where book_id = '" + id + "'");
                    System.out.println("Congratulations, your borrow is successful!");
                    return -1;
                }
                if (msg.equals("2")) {
                    stmt.executeQuery("update stat set Is_reserved = 'YES' where book_id = '" + id + "'");
                    stmt.executeQuery("insert into reserve_order(book_id,account_id,cancel_time,is_borrowed,is_canceled) values('" + id + "','" + accountId + "',sysdate+3,'NO')");
                    stmt.executeQuery("update book_record set reserve_times = reserve_times + 1 where book_id = '" + id + "'");
                    System.out.println("Congratulations, your reserve is successful!");
                    return -1;
                }
            }
        } else {
            System.out.println("Sorry, the book is not Available now! You can enter '1' (desire)(notify you when available), '0' (search again) or 'back' (back to main menu)");
            updateMsg();
            if (msg.equals("0")) {
                return 0;
            }
            if (msg.equals("back")) {
                return -1;
            }
            if (msg.equals("1")) {
                stmt.executeQuery("insert into desire values('" + id + "', '" + accountId + "')");
                stmt.executeQuery("update book_record set desire_times = desire_times+1 where book_id = '" + id + "'");
                System.out.println("Congratulations, your desire is successful!");
                return -1;
            }
            while (true) {
                System.out.println("You should enter '1' (borrow)(take it now!), '2' (reserve)(take it in 3 days!), '0' (search again) or 'back' (back to main menu)");
                updateMsg();
                if (msg.equals("0")) {
                    return 0;
                }
                if (msg.equals("back")) {
                    return -1;
                }
                if (msg.equals("1")) {
                    stmt.executeQuery("update stat set IS_borrowed = 'YES' where book_id = '" + id + "'");
                    stmt.executeQuery("insert into borrow_order(book_id,account_id,is_returned,due_time,note_time) values('" + id + "','" + accountId + "','NO',sysdate+28,sysdate+25)");
                    stmt.executeQuery("update book_record set BORROW_times = BORROW_times + 1 where book_id = '" + id + "'");
                    System.out.println("Congratulations, your borrow is successful!");
                    return -1;
                }
                if (msg.equals("2")) {
                    stmt.executeQuery("update stat set Is_reserved = 'YES' where book_id = '" + id + "'");
                    stmt.executeQuery("insert into reserve_order(book_id,account_id,cancel_time,is_borrowed,is_canceled) values('" + id + "','" + accountId + "',sysdate+3,'NO')");
                    stmt.executeQuery("update book_record set reserve_times = reserve_times + 1 where book_id = '" + id + "'");
                    System.out.println("Congratulations, your reserve is successful!");
                    return -1;
                }
            }
        }
    }

    public static void recordFace() throws SQLException {

        Statement stmt = conn.createStatement();
        System.out.println("|--------------------------------------------------------------|");
        System.out.println("|                 Library Management System                    |");
        System.out.println("|                           Record                             |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  |Borrow records:|                                           |");
        ResultSet rset = stmt.executeQuery("select book_name, is_returned, due_time from book a, borrow_order b where a.book_id = b.book_id and b.account_id = '" + accountId + "'");
        while (rset.next()) {
            String bookName = rset.getString("book_name");
            String isReturned = rset.getString("is_returned");
            Date dueDate = rset.getDate("Due_time");
            System.out.println("|  BookId: " + bookName + " Isreturned: " + isReturned + " DueDate: " + dueDate);
        }
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  |Reserve records:|                                          |");
        rset = stmt.executeQuery("select book_name, cancel_time from book a, reserve_order b where a.book_id = b.book_id and b.account_id = '" + accountId + "'");
        while (rset.next()) {
            String bookName = rset.getString("BOOK_name");
            Date cDate = rset.getDate("cancel_time");
            System.out.println("|  BookName: " + bookName + " CancelDate: " + cDate);
        }
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  |Desire records:|                                           |");
        rset = stmt.executeQuery("select book_name from book a, desire b where a.book_id = b.book_id and b.account_id = '" + accountId + "'");
        while (rset.next()) {
            String bookName = rset.getString("BOOK_name");
            System.out.println("|  BookName: " + bookName);
        }
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|                                                              |");
        System.out.println("|--------------------------------------------------------------|");
    }

    public static void noticeFace() throws SQLException {
        Statement stmt = conn.createStatement();
        System.out.println("|--------------------------------------------------------------|");
        System.out.println("|                 Library Management System                    |");
        System.out.println("|                      Notice Board                            |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  | The deadlines of returning these books are approaching: | |");
        ResultSet rset = stmt.executeQuery("select distinct book_name, due_time from book a, borrow_order b where(a.book_id = b.book_id and(b.account_id = '" + accountId + "') and b.note_time < sysdate and b.due_time > sysdate and Is_returned = 'NO')");
        while (rset.next()) {
            String name = rset.getString("book_name");
            Date time = rset.getDate("due_time");
            System.out.println("|  BookName: " + name + " DueDate: " + time.toString());
        }
        System.out.println("|   ----------------------                                     |");
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  | Desired book is available |:                              |");
        rset = stmt.executeQuery("select a.book_name from book a where(a.book_id IN (select b.book_id from stat b where( b.book_id IN (select c.book_id from desire c where c.account_id = '" + accountId + "') and b.Is_borrowed = 'NO' and b.IS_RESERVED = 'NO')))");
        while (rset.next()) {
            String name = rset.getString("book_name");
            System.out.println("|  BookName: " + name);
        }
        System.out.println("|   ----------------------                                     |");
    }

    public static void updateMsg() {
        msg = scanner.nextLine();
    }

    public static void returnFace() throws SQLException {
        Statement stmt = conn.createStatement();
        ResultSet rset = stmt.executeQuery("select book_name, is_returned, due_time from book a, borrow_order b where a.book_id = b.book_id and b.account_id = '" + accountId + "'");
        if (!rset.next()) {
            System.out.println("You don't borrow any book");
            return;
        }
        System.out.println("Your borrowed records are below:");
        ArrayList<String> arrayList = new ArrayList<>();
        int i = 1;
        rset = stmt.executeQuery("select a.book_id,book_name, is_returned, due_time from book a, borrow_order b where a.book_id = b.book_id and is_returned = 'NO' and b.account_id = '" + accountId + "'");
        while (rset.next()) {
            String bookId = rset.getString("book_id");
            String bookName = rset.getString("book_name");
            String isReturned = rset.getString("is_returned");
            Date dueDate = rset.getDate("Due_time");
            System.out.println("|  Number of book: " + i + "|  BookName: " + bookName + " Isreturned: " + isReturned + " DueDate: " + dueDate);
            arrayList.add(bookId);
            i++;
        }
        System.out.println("Please enter the number of the book to return. If you don't find your book,  or you want" +
                           " to go back to main page, please enter \"back\"");
        updateMsg();
        if (msg.equals("back")) {
            return;
        }
        boolean flag = true;
        if (msg.equals("")){
            flag = false;}
        else {
            for (int j = 0; j < msg.length(); j++) {
                if (!(msg.charAt(j) <= '9' && msg.charAt(j) >= '0')) {
                    flag = false;
                    break;
                }
                if ((Integer.parseInt(msg) > arrayList.size()) || (Integer.parseInt(msg) < 1)) flag = false;
            }
        }
        while (true) {
            if (flag == false) {
                System.out.println("You have to enter a book number, or enter back to go back to main!");
                updateMsg();
                if (msg.equals("back")) {
                    return;
                }
                flag = true;
                if (msg.equals("")){
                    flag = false;}
                else {
                    for (int j = 0; j < msg.length(); j++) {
                        if (!(msg.charAt(j) <= '9' && msg.charAt(j) >= '0')) {
                            flag = false;
                            break;
                        }
                        if ((Integer.parseInt(msg) > arrayList.size() + 1) || (Integer.parseInt(msg) < 1)) flag = false;
                    }
                }
            } else break;
        }
        int index = Integer.parseInt(msg) - 1;
        String id = arrayList.get(index);
        rset = stmt.executeQuery("update stat set Is_borrowed = 'NO' where book_id = '" + id + "'");
        rset = stmt.executeQuery("update borrow_order set Is_returned = 'YES' where book_id = '" + id + "'");
        System.out.println("return successfully");
    }

    public static void cancelFace() throws SQLException {
        Statement stmt = conn.createStatement();
        ResultSet rset = stmt.executeQuery("select book_name, cancel_time from book a, reserve_order b where a.book_id = b.book_id and b.account_id = '" + accountId + "'");
        if (!rset.next()) {
            System.out.println("You don't reserve any book");
            return;
        }
        System.out.println("Your reserved records are below:");
        ArrayList<String> arrayList = new ArrayList<>();
        int i = 1;
        rset = stmt.executeQuery("select a.book_id, book_name, cancel_time from book a, reserve_order b where a.book_id = b.book_id and is_canceled = 'NO' and b.account_id = '" + accountId + "'");
        while (rset.next()) {
            String book_id = rset.getString("book_id");
            String book_name = rset.getString("book_name");
            Date cancelDate = rset.getDate("cancel_time");
            System.out.println("|  Number of book: " + i + "|  BookId: " + book_id + " BookName: " + book_name + " CancelDate: " + cancelDate);
            arrayList.add(book_id);
            i++;
        }
        System.out.println("Please enter the number of the book to cancel. If you don't find your book,  or you want to go back to main page, please enter \"back\"");
        updateMsg();
        if (msg.equals("back")) {
            return;
        }
        boolean flag = true;
        if (msg.equals("")){
            flag = false;}
        else {
            for (int j = 0; j < msg.length(); j++) {
                if (!(msg.charAt(j) <= '9' && msg.charAt(j) >= '0')) {
                    flag = false;
                    break;
                }
                if ((Integer.parseInt(msg) > arrayList.size()) || (Integer.parseInt(msg) < 1)) flag = false;
            }
        }
        while (true) {
            if (flag == false) {
                System.out.println("You have to enter a book number, or enter 'back' to go back to main!");
                updateMsg();
                if (msg.equals("back")) {
                    return;
                }
                flag = true;
                if (msg.equals("")){
                    flag = false;}
                else {
                    for (int j = 0; j < msg.length(); j++) {
                        if (!(msg.charAt(j) <= '9' && msg.charAt(j) >= '0')) {
                            flag = false;
                            break;
                        }
                        if ((Integer.parseInt(msg) > arrayList.size() + 1) || (Integer.parseInt(msg) < 1)) flag = false;
                    }
                }
            } else break;
        }
        int index = Integer.parseInt(msg) - 1;
        String id = arrayList.get(index);
        rset = stmt.executeQuery("update stat set Is_reserved = 'NO' where book_id = '" + id + "'");
        rset = stmt.executeQuery("update reserve_order set is_canceled = 'YES',cancel_time = sysdate where book_id = '" + id + "'");
        System.out.println("cancel successfully");
    }

    public static void reportFace() throws SQLException {
        Statement stmt = conn.createStatement();
        System.out.println("|--------------------------------------------------------------|");
        System.out.println("|                 Library Management System                    |");
        System.out.println("|                           Report                             |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  |Book_record:|                                              |");
        ResultSet rset = stmt.executeQuery("select * from book_record order by borrow_TIMES");
        int i = 1;
        while (rset.next()) {
            String book_id = rset.getString("book_id");
            int BORROW_TIMES = rset.getInt("BORROW_TIMES");
            int DESIRE_TIMES = rset.getInt("DESIRE_TIMES");
            int RESERVE_TIMES = rset.getInt("RESERVE_TIMES");
            System.out.println("|  Number of book: " + i + "|  BookId: " + book_id + " Borrow_times: " + BORROW_TIMES + " Reserve_times: " + RESERVE_TIMES + " Desire_times: " + DESIRE_TIMES);
            i++;
        }
        System.out.println("|   ----------------------                                     |");
        System.out.println("|                                                              |");
        System.out.println("|   ----------------------                                     |");
        System.out.println("|  | DEACTVATED_record |:                                      |");
        rset = stmt.executeQuery("select account_id from patron_account where IS_DEACTIVATED = 'YES'");
        i = 1;
        while (rset.next()) {
            String account_id = rset.getString("account_id");
            System.out.println("|  Number of account: " + i + "|  account_id: " + account_id);
            i++;
        }
    }

    public static void deactivateFace() throws SQLException {
        System.out.println("Enter a Patron Account ID to deactivate");
        updateMsg();
        Statement stmt = conn.createStatement();
        ResultSet rset = stmt.executeQuery(String.format("select ACCOUNT_ID from PATRON_ACCOUNT where " +
                                                         "ACCOUNT_ID='%s'", msg));
        while (!rset.next()) {
            System.out.printf("No Patron Account Id %s is found!%n", msg);
            updateMsg();
            rset = stmt.executeQuery(String.format("select ACCOUNT_ID from PATRON_ACCOUNT where " +
                                                   "ACCOUNT_ID='%s'", msg));
        }
        stmt.executeQuery(String.format("update PATRON_ACCOUNT set IS_DEACTIVATED='YES' where ACCOUNT_ID='%s'", msg));
        System.out.printf("Patron '%s' has been deactivated!!!%n", msg);
    }

    public static void activateFace() throws SQLException {
        System.out.println("Enter a Patron Account ID to activate");
        updateMsg();
        Statement stmt = conn.createStatement();
        ResultSet rset = stmt.executeQuery(String.format("select ACCOUNT_ID from PATRON_ACCOUNT where " +
                                                         "ACCOUNT_ID='%s'", msg));
        while (!rset.next()) {
            System.out.printf("No Patron Account Id %s is found!%n", msg);
            updateMsg();
            rset = stmt.executeQuery(String.format("select ACCOUNT_ID from PATRON_ACCOUNT where " +
                                                   "ACCOUNT_ID='%s'", msg));
        }
        stmt.executeQuery(String.format("update PATRON_ACCOUNT set IS_DEACTIVATED='NO' where ACCOUNT_ID='%s'", msg));
        System.out.printf("Patron '%s' has been activated!!!%n", msg);
    }

    // send email
    public static void sendEmail(String receiver, String bookName) {
        String myEmailAccount = "l995lll0@qq.com";
        String myEmailPassword = "twxeibwfxjhkbebg";
        String myEmailSMTPHost = "smtp.qq.com";
        String receiveMailAccount = receiver;
        Properties props = new Properties();
        props.setProperty("mail.transport.protocol", "smtp");
        props.setProperty("mail.smtp.host", myEmailSMTPHost);
        props.setProperty("mail.smtp.auth", "true");
        final String smtpPort = "465";
        props.setProperty("mail.smtp.port", smtpPort);
        props.setProperty("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.setProperty("mail.smtp.socketFactory.fallback", "false");
        props.setProperty("mail.smtp.socketFactory.port", smtpPort);
        Session session = Session.getInstance(props);
        session.setDebug(false);
        MimeMessage message;
        try {
            message = createMimeMessage(session, myEmailAccount, receiveMailAccount, bookName);
            Transport transport = session.getTransport();
            transport.connect(myEmailAccount, myEmailPassword);
            transport.sendMessage(message, message.getAllRecipients());
            transport.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static MimeMessage createMimeMessage(Session session, String sendMail, String receiveMail,
                                                 String bookName) throws Exception {
        MimeMessage message = new MimeMessage(session);
        message.setFrom(new InternetAddress(sendMail, "LMS", "UTF-8"));
        message.setRecipient(MimeMessage.RecipientType.TO, new InternetAddress(receiveMail, "user", "UTF-8"));
        message.setSubject("COMP2411-Desired Book Available", "UTF-8");
        message.setContent(String.format("'%s' is available now!", bookName), "text/html;charset=UTF-8");
        message.setSentDate(new java.util.Date());
        message.saveChanges();
        return message;
    }

}


